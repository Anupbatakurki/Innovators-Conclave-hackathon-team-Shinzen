# GreenLedger — Campus Digital Twin UI

Standalone, animated frontend for **GreenLedger — Campus Resource Optimisation Software** (IC26-05-01 Sustainability & Climate Action).

All readings are **demo / sample data**. No backend, API keys or external services are needed (Google Fonts load online; the UI falls back to system fonts offline).

## Run

```bash
npm install        # or: bun install
npm run dev        # http://localhost:8080 (Vite)
npm run build      # production build
```

Requires Node 20+.

## Stack
React 19 · TypeScript · Vite · TanStack Router/Start · Tailwind CSS v4 · Framer Motion · Recharts · Lucide icons.

## Where to edit
| What | File |
|---|---|
| Campus image | `public/images/university-campus.png` |
| Building names, marker x/y (% of image), demo readings, sensor links | `src/data/campus.ts` |
| Aggregation, chart series, alerts, ticker, recommendations (replace with API calls) | `src/data/metrics.ts` |
| Colours, glow, animations | `src/styles.css` |
| Navigation items | `src/components/navigation/nav-items.ts` |

## Features
- Interactive digital-twin map: pulsing sensor markers, animated data links, scan line, grid, hover tooltips, click-to-select, zoom / pan / reset / fullscreen, sensor-category filters, status legend, live-status ticker.
- Panels: Energy Intelligence, Air Quality, Water Flow, Carbon Impact, Waste Management — all react to the selected building and Today / 7 Days / 30 Days.
- Insights panel, building detail dialog, alerts drawer, 12 working sections (Overview, Campus Map, Buildings, Energy, Water, Waste, Carbon, Sustainability, Analytics, Recommendations, Reports with CSV export, Settings).
- Responsive: mobile drawer nav, stacked panels; respects `prefers-reduced-motion`.
