import { createFileRoute } from "@tanstack/react-router";
import { CampusViewport } from "@/components/campus/CampusViewport";
import { AirPanel, CarbonPanel, EnergyPanel, PeriodSelector, WastePanel, WaterPanel } from "@/components/panels/MetricPanels";
import { InsightPanel, SelectedBuildingCard } from "@/components/panels/InsightPanel";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GreenLedger — Campus Digital Twin" },
      { name: "description", content: "Smart campus resource monitoring: energy, water, waste and carbon across university buildings on an interactive digital twin." },
      { property: "og:title", content: "GreenLedger — Campus Digital Twin" },
      { property: "og:description", content: "Interactive digital twin for campus sustainability and resource optimisation." },
    ],
  }),
  component: Overview,
});

function Overview() {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <div>
          <h1 className="text-lg font-semibold tracking-wide">Overview</h1>
          <p className="text-xs text-muted-foreground">Smart University Operations · simulated sample readings</p>
        </div>
        <div className="ml-auto"><PeriodSelector /></div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
        <div className="space-y-4">
          <div className="relative">
            <CampusViewport />
            {/* Floating panels over the twin on very wide screens */}
            <div className="pointer-events-none absolute bottom-12 left-3 hidden w-60 space-y-3 2xl:block [&>*]:pointer-events-auto">
              <EnergyPanel delay={0.2} />
              <AirPanel delay={0.3} />
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-3">
            <div className="2xl:hidden"><EnergyPanel delay={0.2} /></div>
            <div className="2xl:hidden"><AirPanel delay={0.25} /></div>
            <WaterPanel delay={0.3} />
            <CarbonPanel delay={0.35} />
            <WastePanel delay={0.4} />
          </div>
        </div>
        <aside className="space-y-4">
          <SelectedBuildingCard />
          <InsightPanel />
        </aside>
      </div>
    </div>
  );
}
