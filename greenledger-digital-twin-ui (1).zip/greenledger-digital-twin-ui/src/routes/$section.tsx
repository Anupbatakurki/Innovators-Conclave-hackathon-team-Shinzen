import { createFileRoute, notFound } from "@tanstack/react-router";
import { navItems, sectionSlugs } from "@/components/navigation/nav-items";
import { SectionView } from "@/components/pages/SectionView";

export const Route = createFileRoute("/$section")({
  beforeLoad: ({ params }) => {
    if (!sectionSlugs.includes(params.section)) throw notFound();
  },
  head: ({ params }) => {
    const label = navItems.find((n) => n.slug === params.section)?.label ?? "Section";
    const title = `${label} — GreenLedger Campus Digital Twin`;
    const description = `${label} view of the GreenLedger smart campus resource monitoring dashboard (demo data).`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
      ],
    };
  },
  component: SectionPage,
});

function SectionPage() {
  const { section } = Route.useParams();
  return <SectionView slug={section} />;
}
