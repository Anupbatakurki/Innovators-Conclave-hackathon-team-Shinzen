import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState, type ReactElement } from "react";
import { ArrowLeft, Download, FileText } from "lucide-react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { buildings, type DailyReadings } from "@/data/campus";
import { aggregate, fmt, periodDays, periodLabel, recommendations, series } from "@/data/metrics";
import { useDashboard } from "@/lib/dashboard-context";
import { navItems } from "@/components/navigation/nav-items";
import { CampusViewport, categoryMeta } from "@/components/campus/CampusViewport";
import { AirPanel, CarbonPanel, chartTooltip, EnergyPanel, PeriodSelector, WastePanel, WaterPanel } from "@/components/panels/MetricPanels";
import { InsightPanel, SelectedBuildingCard } from "@/components/panels/InsightPanel";
import { cn } from "@/lib/utils";

type ResKey = "energyKwh" | "waterL" | "carbonKg" | "wasteKg";
const resource: Record<string, { key: ResKey; unit: string; Panel: () => ReactElement; blurb: string }> = {
  energy: { key: "energyKwh", unit: "kWh", Panel: () => <EnergyPanel />, blurb: "Electricity consumption across campus buildings." },
  water: { key: "waterL", unit: "L", Panel: () => <WaterPanel />, blurb: "Water consumption, flow and reuse by building." },
  waste: { key: "wasteKg", unit: "kg", Panel: () => <WastePanel />, blurb: "Waste collected and recycling performance." },
  carbon: { key: "carbonKg", unit: "kg CO₂e", Panel: () => <CarbonPanel />, blurb: "Estimated emissions and carbon avoided." },
  analytics: { key: "energyKwh", unit: "kWh", Panel: () => <AirPanel />, blurb: "Cross-resource trends and comparisons." },
};

function Header({ slug }: { slug: string }) {
  const item = navItems.find((n) => n.slug === slug)!;
  return (
    <div className="mb-4 flex flex-wrap items-center gap-3">
      <Link to="/" className="flex items-center gap-1 rounded-md border px-2 py-1 text-xs text-muted-foreground hover:border-cyan/50 hover:text-cyan">
        <ArrowLeft className="h-3 w-3" /> Overview
      </Link>
      <item.icon className="h-5 w-5 text-cyan" />
      <h1 className="text-lg font-semibold tracking-wide">{item.label}</h1>
      <span className="rounded-full border border-amber/40 px-2 py-0.5 text-[10px] text-amber">Demo data</span>
      <div className="ml-auto"><PeriodSelector /></div>
    </div>
  );
}

function ResourceView({ slug }: { slug: string }) {
  const { period, selected, selectId } = useDashboard();
  const cfg = resource[slug]!;
  const d = periodDays[period];
  const bars = buildings.map((b) => ({ id: b.id, name: b.name.split(" (")[0], value: Math.round((b.readings[cfg.key as keyof DailyReadings] as number) * d) }));
  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_320px]">
      <div className="space-y-4">
        <p className="text-sm text-muted-foreground">{cfg.blurb}</p>
        <div className="glass p-4">
          <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Trend · {selected?.name ?? "Entire campus"} · {periodLabel[period]}</div>
          <div className="h-64">
            <ResponsiveContainer>
              <AreaChart data={series(selected, period, cfg.key)}>
                <defs><linearGradient id="rv" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="var(--teal)" stopOpacity={0.4} /><stop offset="1" stopColor="var(--teal)" stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} width={48} />
                <Tooltip {...chartTooltip} formatter={(v: number) => [`${fmt(v)} ${cfg.unit}`]} />
                <Area dataKey="prev" name="Previous" stroke="var(--muted-foreground)" strokeDasharray="3 3" fill="none" />
                <Area dataKey="value" name="Current" stroke="var(--teal)" strokeWidth={2} fill="url(#rv)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass p-4">
          <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">By building ({cfg.unit}) · click a bar to select</div>
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={bars} onClick={(e) => { const id = (e?.activePayload?.[0]?.payload as { id?: string })?.id; if (id) selectId(id); }}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} interval={0} angle={-15} height={50} textAnchor="end" />
                <YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} width={48} />
                <Tooltip {...chartTooltip} cursor={{ fill: "var(--secondary)" }} formatter={(v: number) => [`${fmt(v)} ${cfg.unit}`]} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]} fill="var(--cyan)" fillOpacity={0.75} className="cursor-pointer" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      <div className="space-y-4"><SelectedBuildingCard /><cfg.Panel />{slug === "analytics" && <><EnergyPanel /><WaterPanel /></>}</div>
    </div>
  );
}

function BuildingsView() {
  const { period, selectId, setDetailOpen } = useDashboard();
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      {buildings.map((b, i) => {
        const a = aggregate(b, period);
        const M = categoryMeta[b.category];
        return (
          <motion.button key={b.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
            onClick={() => { selectId(b.id); setDetailOpen(true); }} className="glass p-4 text-left transition-colors hover:border-cyan/50">
            <div className="flex items-center justify-between"><M.icon className={cn("h-4 w-4", M.tone)} />
              <span className={cn("rounded-full px-2 py-0.5 text-[10px] capitalize", b.status === "optimal" ? "bg-teal/15 text-teal" : b.status === "warning" ? "bg-amber/15 text-amber" : "bg-coral/15 text-coral")}>{b.status}</span></div>
            <div className="mt-2 font-medium">{b.name}</div>
            <div className="text-[11px] text-muted-foreground">{b.zone}</div>
            <div className="mt-3 grid grid-cols-2 gap-1 font-mono text-[11px]">
              <span className="text-muted-foreground">Energy</span><span>{fmt(a.energyKwh)} kWh</span>
              <span className="text-muted-foreground">Water</span><span>{fmt(a.waterL)} L</span>
              <span className="text-muted-foreground">Score</span><span className="text-lime">{b.score}/100</span>
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}

function SustainabilityView() {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <InsightPanel />
      <div className="space-y-4 lg:col-span-2">
        <CarbonPanel />
        <div className="glass p-4">
          <div className="mb-3 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Building sustainability scores</div>
          <div className="space-y-2">
            {[...buildings].sort((a, b) => b.score - a.score).map((b) => (
              <div key={b.id} className="flex items-center gap-3 text-sm">
                <span className="w-44 truncate">{b.name}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary"><motion.div className={cn("h-full rounded-full", b.score >= 75 ? "bg-lime" : b.score >= 60 ? "bg-amber" : "bg-coral")} initial={{ width: 0 }} animate={{ width: `${b.score}%` }} transition={{ duration: 0.9 }} /></div>
                <span className="w-10 text-right font-mono text-xs">{b.score}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function RecommendationsView() {
  const { selectId, setDetailOpen } = useDashboard();
  const [done, setDone] = useState<string[]>([]);
  return (
    <div className="space-y-3">
      {recommendations.map((r) => {
        const b = buildings.find((x) => x.id === r.buildingId)!;
        const isDone = done.includes(r.id);
        return (
          <div key={r.id} className={cn("glass flex flex-wrap items-center gap-3 p-4", isDone && "opacity-50")}>
            <span className={cn("rounded-full px-2 py-0.5 text-[10px] uppercase", r.priority === "high" ? "bg-coral/15 text-coral" : r.priority === "medium" ? "bg-amber/15 text-amber" : "bg-teal/15 text-teal")}>{r.priority}</span>
            <div className="min-w-0 flex-1">
              <div className="font-medium">{r.title}</div>
              <div className="text-xs text-muted-foreground">{b.name} · {r.detail}</div>
            </div>
            <span className="font-mono text-xs text-lime">{r.impact}</span>
            <button onClick={() => { selectId(b.id); setDetailOpen(true); }} className="rounded-md border px-3 py-1 text-xs hover:border-cyan/50 hover:text-cyan">View building</button>
            <button onClick={() => setDone((d) => (isDone ? d.filter((x) => x !== r.id) : [...d, r.id]))} className="rounded-md bg-cyan/15 px-3 py-1 text-xs text-cyan hover:bg-cyan/25">{isDone ? "Reopen" : "Mark planned"}</button>
          </div>
        );
      })}
    </div>
  );
}

function ReportsView() {
  const { period } = useDashboard();
  const download = () => {
    const d = periodDays[period];
    const rows = [["Building", "Zone", "Energy kWh", "Water L", "CO2e kg", "Waste kg", "Score"],
      ...buildings.map((b) => [b.name, b.zone, b.readings.energyKwh * d, b.readings.waterL * d, b.readings.carbonKg * d, b.readings.wasteKg * d, b.score])];
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url; a.download = `greenledger-demo-report-${period}.csv`; a.click();
    URL.revokeObjectURL(url);
  };
  const reports = ["Campus resource summary", "Building energy league table", "Carbon footprint statement", "Water & waste performance"];
  return (
    <div className="grid gap-3 md:grid-cols-2">
      {reports.map((r) => (
        <div key={r} className="glass flex items-center gap-3 p-4">
          <FileText className="h-5 w-5 text-cyan" />
          <div className="flex-1"><div className="font-medium">{r}</div><div className="text-xs text-muted-foreground">{periodLabel[period]} · sample data · CSV</div></div>
          <button onClick={download} className="flex items-center gap-1 rounded-md bg-cyan px-3 py-1.5 text-xs font-medium text-primary-foreground"><Download className="h-3 w-3" /> Export</button>
        </div>
      ))}
    </div>
  );
}

function SettingsView() {
  const [s, setS] = useState({ alerts: true, scan: true, labels: true, units: "metric" });
  const toggle = (k: "alerts" | "scan" | "labels") => setS((x) => ({ ...x, [k]: !x[k] }));
  const rows: [typeof toggle extends (k: infer K) => void ? K : never, string][] = [["alerts", "Critical alert notifications"], ["scan", "Map scanning effect"], ["labels", "Show marker readings"]];
  return (
    <div className="glass max-w-xl divide-y">
      {rows.map(([k, l]) => (
        <label key={k} className="flex cursor-pointer items-center justify-between p-4 text-sm">
          {l}
          <button role="switch" aria-checked={s[k]} onClick={() => toggle(k)} className={cn("relative h-5 w-9 rounded-full transition-colors", s[k] ? "bg-cyan" : "bg-secondary")}>
            <span className={cn("absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition-all", s[k] ? "left-[18px]" : "left-0.5")} />
          </button>
        </label>
      ))}
      <div className="p-4 text-xs text-muted-foreground">Preferences are local to this demo session. Data source: built-in sample dataset (no backend connected).</div>
    </div>
  );
}

export function SectionView({ slug }: { slug: string }) {
  let body: ReactElement;
  if (slug === "campus-map") body = <div className="grid gap-4 xl:grid-cols-[1fr_320px]"><CampusViewport /><div className="space-y-4"><SelectedBuildingCard /><InsightPanel /></div></div>;
  else if (slug === "buildings") body = <BuildingsView />;
  else if (slug === "sustainability") body = <SustainabilityView />;
  else if (slug === "recommendations") body = <RecommendationsView />;
  else if (slug === "reports") body = <ReportsView />;
  else if (slug === "settings") body = <SettingsView />;
  else body = <ResourceView slug={slug} />;
  return (<><Header slug={slug} />{body}</>);
}
