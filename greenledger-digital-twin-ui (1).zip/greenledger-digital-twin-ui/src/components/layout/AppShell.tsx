import { Link, useLocation } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { Bell, Maximize2, Menu, UserCircle2, X, Activity } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { navItems } from "@/components/navigation/nav-items";
import { useDashboard } from "@/lib/dashboard-context";
import { alerts } from "@/data/metrics";
import { cn } from "@/lib/utils";

function Clock() {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  if (!now) return <span className="font-mono text-xs text-muted-foreground">--:--:--</span>;
  return (
    <div className="hidden text-right font-mono leading-tight md:block">
      <div className="text-sm text-foreground">{now.toLocaleTimeString("en-GB")}</div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
        {now.toLocaleDateString("en-GB", { weekday: "short", day: "2-digit", month: "short", year: "numeric" })}
      </div>
    </div>
  );
}

function SideNav({ onNavigate }: { onNavigate?: () => void }) {
  const { pathname } = useLocation();
  return (
    <nav className="flex flex-col gap-0.5 p-2">
      {navItems.map((item) => {
        const href = item.slug ? `/${item.slug}` : "/";
        const active = pathname === href;
        const Icon = item.icon;
        return (
          <Link
            key={item.label}
            to={item.slug ? "/$section" : "/"}
            params={{ section: item.slug }}
            onClick={onNavigate}
            className={cn(
              "group relative flex items-center gap-3 rounded-md px-3 py-2 text-[13px] transition-colors",
              active
                ? "bg-cyan/10 text-cyan"
                : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground",
            )}
          >
            {active && (
              <motion.span
                layoutId="nav-active"
                className="absolute inset-y-1 left-0 w-[3px] rounded-full bg-cyan shadow-[var(--glow-cyan)]"
              />
            )}
            <Icon className={cn("h-4 w-4 shrink-0", active && "drop-shadow-[0_0_6px_var(--cyan)]")} />
            <span className="truncate">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { alertsOpen, setAlertsOpen, mobileNavOpen, setMobileNavOpen, selectId } = useDashboard();
  const { pathname } = useLocation();

  const toggleFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen?.();
  };

  return (
    <div className="circuit-bg flex min-h-screen flex-col">
      <header className="relative z-30 flex h-16 items-center gap-3 border-b bg-background/70 px-4 backdrop-blur-md">
        <button
          className="rounded-md p-2 text-muted-foreground hover:text-foreground lg:hidden"
          onClick={() => setMobileNavOpen(true)}
          aria-label="Open navigation"
        >
          <Menu className="h-5 w-5" />
        </button>
        <Link to="/" className="flex items-center gap-3">
          <div className="grid h-9 w-9 place-items-center rounded-lg border border-cyan/40 bg-cyan/10">
            <svg viewBox="0 0 24 24" className="h-5 w-5 text-lime" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M12 3c5 3 7 7 6 12-3 3-9 3-12 0C5 10 7 6 12 3Z" />
              <path d="M12 7v13" />
            </svg>
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold tracking-[0.2em] sm:text-base">
              GREENLEDGER <span className="text-cyan/60">|</span>{" "}
              <span className="glow-text text-cyan">CAMPUS DIGITAL TWIN</span>
            </div>
            <div className="hidden text-[11px] text-muted-foreground sm:block">
              Smart Campus Resource Monitoring & Optimisation
            </div>
          </div>
        </Link>
        <div className="ml-auto flex items-center gap-2 sm:gap-4">
          <div className="hidden items-center gap-2 rounded-full border border-teal/30 bg-teal/10 px-3 py-1 text-[11px] text-teal xl:flex">
            <span className="relative flex h-2 w-2">
              <span className="pulse-ring absolute inset-0 rounded-full bg-teal" />
              <span className="relative h-2 w-2 rounded-full bg-teal" />
            </span>
            Campus status: Operational · Demo data
          </div>
          <Clock />
          <button
            onClick={() => setAlertsOpen(true)}
            className="relative rounded-md p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Open notifications"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute right-1 top-1 grid h-4 w-4 place-items-center rounded-full bg-coral text-[9px] font-bold text-background">
              {alerts.length}
            </span>
          </button>
          <button
            onClick={toggleFullscreen}
            className="hidden rounded-md p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground sm:block"
            aria-label="Toggle fullscreen"
          >
            <Maximize2 className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2 rounded-full border bg-secondary/50 py-1 pl-1 pr-3">
            <UserCircle2 className="h-7 w-7 text-cyan" />
            <span className="hidden text-xs sm:inline">Sustainability Office</span>
          </div>
        </div>
        <div className="header-glow absolute inset-x-0 bottom-0 h-px" />
      </header>

      <div className="flex flex-1">
        <aside className="sticky top-0 hidden h-[calc(100vh-4rem)] w-56 shrink-0 overflow-y-auto border-r bg-panel/60 backdrop-blur-md lg:block">
          <SideNav />
          <div className="mx-3 mt-4 rounded-md border border-dashed p-3 text-[11px] leading-relaxed text-muted-foreground">
            All readings shown are <span className="text-amber">demo / sample data</span>. No live sensors are connected.
          </div>
        </aside>

        <main className="min-w-0 flex-1 p-3 sm:p-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile nav drawer */}
      <AnimatePresence>
        {mobileNavOpen && (
          <>
            <motion.div className="fixed inset-0 z-40 bg-background/70 lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setMobileNavOpen(false)} />
            <motion.aside className="fixed inset-y-0 left-0 z-50 w-64 border-r bg-panel lg:hidden" initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }} transition={{ type: "spring", damping: 28, stiffness: 260 }}>
              <div className="flex h-16 items-center justify-between border-b px-4">
                <span className="text-sm tracking-widest text-cyan">NAVIGATION</span>
                <button onClick={() => setMobileNavOpen(false)} aria-label="Close navigation"><X className="h-5 w-5" /></button>
              </div>
              <SideNav onNavigate={() => setMobileNavOpen(false)} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Alerts drawer */}
      <AnimatePresence>
        {alertsOpen && (
          <>
            <motion.div className="fixed inset-0 z-40 bg-background/60" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setAlertsOpen(false)} />
            <motion.aside className="fixed inset-y-0 right-0 z-50 flex w-full max-w-sm flex-col border-l bg-panel" initial={{ x: 400 }} animate={{ x: 0 }} exit={{ x: 400 }} transition={{ type: "spring", damping: 30, stiffness: 260 }}>
              <div className="flex h-16 items-center justify-between border-b px-4">
                <div className="flex items-center gap-2"><Activity className="h-4 w-4 text-cyan" /><span className="text-sm tracking-widest">ALERTS</span></div>
                <button onClick={() => setAlertsOpen(false)} aria-label="Close alerts"><X className="h-5 w-5" /></button>
              </div>
              <div className="flex-1 space-y-2 overflow-y-auto p-4">
                {alerts.map((a, i) => (
                  <motion.button
                    key={a.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                    onClick={() => { if (a.buildingId) selectId(a.buildingId); setAlertsOpen(false); }}
                    className="glass w-full p-3 text-left transition-colors hover:border-cyan/50"
                  >
                    <div className="flex items-center gap-2">
                      <span className={cn("h-2 w-2 rounded-full", a.level === "critical" ? "bg-coral" : a.level === "warning" ? "bg-amber" : "bg-teal")} />
                      <span className="text-[10px] uppercase tracking-widest text-muted-foreground">{a.level} · {a.time}</span>
                    </div>
                    <div className="mt-1 text-sm">{a.title}</div>
                    {a.buildingId && <div className="mt-1 text-[11px] text-cyan">Locate on campus →</div>}
                  </motion.button>
                ))}
                <p className="pt-2 text-center text-[11px] text-muted-foreground">Sample alerts for demonstration.</p>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
