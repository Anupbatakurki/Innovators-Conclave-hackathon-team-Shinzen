import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useEffect } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { aggregate, fmt, periodLabel, recommendations, series } from "@/data/metrics";
import { useDashboard } from "@/lib/dashboard-context";
import { chartTooltip, PeriodSelector } from "@/components/panels/MetricPanels";

export function BuildingDialog() {
  const { selected, detailOpen, setDetailOpen, period } = useDashboard();
  const open = detailOpen && !!selected;
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && setDetailOpen(false);
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [setDetailOpen]);
  return (
    <AnimatePresence>
      {open && selected && (
        <motion.div className="fixed inset-0 z-50 grid place-items-center bg-background/70 p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setDetailOpen(false)}>
          <motion.div
            role="dialog"
            aria-label={`${selected.name} details`}
            initial={{ y: 20, scale: 0.97 }} animate={{ y: 0, scale: 1 }} exit={{ y: 10, opacity: 0 }}
            className="glass max-h-[90vh] w-full max-w-3xl overflow-y-auto bg-panel p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-cyan">{selected.zone}</div>
                <h2 className="text-xl font-semibold">{selected.name}</h2>
                <p className="text-xs text-muted-foreground">Sample readings · {periodLabel[period]}</p>
              </div>
              <div className="flex items-center gap-2">
                <PeriodSelector />
                <button onClick={() => setDetailOpen(false)} aria-label="Close"><X className="h-5 w-5" /></button>
              </div>
            </div>
            {(() => {
              const a = aggregate(selected, period);
              const stats = [
                ["Energy", `${fmt(a.energyKwh)} kWh`], ["Energy saved", `${a.energySavedPct.toFixed(1)}%`],
                ["Water", `${fmt(a.waterL)} L`], ["Water reused", `${Math.round(a.recycledWaterPct)}%`],
                ["CO₂e emitted", `${fmt(a.carbonKg)} kg`], ["CO₂e avoided", `${fmt(a.carbonAvoidedKg)} kg`],
                ["Waste", `${fmt(a.wasteKg)} kg`], ["AQI / CO₂", `${a.aqi} / ${a.co2ppm} ppm`],
              ];
              return (
                <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {stats.map(([l, v]) => (
                    <div key={l} className="rounded-md border bg-background/40 p-2">
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{l}</div>
                      <div className="font-mono text-sm">{v}</div>
                    </div>
                  ))}
                </div>
              );
            })()}
            <div className="mt-4 h-52">
              <ResponsiveContainer>
                <AreaChart data={series(selected, period)}>
                  <defs><linearGradient id="bd" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="var(--cyan)" stopOpacity={0.4} /><stop offset="1" stopColor="var(--cyan)" stopOpacity={0} /></linearGradient></defs>
                  <CartesianGrid stroke="var(--border)" vertical={false} />
                  <XAxis dataKey="label" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} axisLine={false} tickLine={false} width={40} />
                  <Tooltip {...chartTooltip} />
                  <Area dataKey="prev" name="Previous" stroke="var(--muted-foreground)" strokeDasharray="3 3" fill="none" />
                  <Area dataKey="value" name="Energy kWh" stroke="var(--cyan)" fill="url(#bd)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4">
              <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Recommendations</div>
              <ul className="mt-2 space-y-2">
                {recommendations.filter((r) => r.buildingId === selected.id).map((r) => (
                  <li key={r.id} className="rounded-md border bg-background/40 p-2 text-sm">
                    <div className="flex justify-between gap-2"><span>{r.title}</span><span className="font-mono text-xs text-lime">{r.impact}</span></div>
                    <div className="text-xs text-muted-foreground">{r.detail}</div>
                  </li>
                ))}
                {!recommendations.some((r) => r.buildingId === selected.id) && <li className="text-xs text-muted-foreground">No open recommendations — building performing well.</li>}
              </ul>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
