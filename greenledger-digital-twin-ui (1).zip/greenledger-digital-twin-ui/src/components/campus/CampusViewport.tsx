import { AnimatePresence, motion, useMotionValue, animate } from "framer-motion";
import { Zap, Droplets, Trash2, Wind, Factory, Sun, Plus, Minus, RotateCcw, Expand, type LucideIcon } from "lucide-react";
import { useRef, useState } from "react";
import { buildings, sensorLinks, CAMPUS_IMAGE, CAMPUS_IMAGE_RATIO, type SensorCategory, type Building } from "@/data/campus";
import { fmt, tickerMessages } from "@/data/metrics";
import { useDashboard, allCategories } from "@/lib/dashboard-context";
import { cn } from "@/lib/utils";

export const categoryMeta: Record<SensorCategory, { label: string; icon: LucideIcon; tone: string }> = {
  energy: { label: "Energy", icon: Zap, tone: "text-cyan" },
  water: { label: "Water", icon: Droplets, tone: "text-cyan" },
  waste: { label: "Waste", icon: Trash2, tone: "text-teal" },
  air: { label: "Air quality", icon: Wind, tone: "text-teal" },
  carbon: { label: "Carbon", icon: Factory, tone: "text-lime" },
  renewable: { label: "Renewable", icon: Sun, tone: "text-lime" },
};

const statusRing: Record<Building["status"], string> = {
  optimal: "bg-teal",
  warning: "bg-amber",
  critical: "bg-coral",
};

function Marker({ b, scale }: { b: Building; scale: number }) {
  const { selected, selectId } = useDashboard();
  const [hover, setHover] = useState(false);
  const meta = categoryMeta[b.category];
  const Icon = meta.icon;
  const isSel = selected?.id === b.id;
  return (
    <div
      className="absolute z-10"
      style={{ left: `${b.x}%`, top: `${b.y}%`, transform: `translate(-50%, -50%) scale(${1 / scale})` }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <button
        onClick={(e) => { e.stopPropagation(); selectId(isSel ? null : b.id); }}
        aria-label={`Select ${b.name}`}
        className="relative grid h-9 w-9 place-items-center"
      >
        <span className={cn("pulse-ring absolute inset-0 rounded-full", statusRing[b.status], "opacity-60")} />
        <span
          className={cn(
            "relative grid h-8 w-8 place-items-center rounded-full border bg-background/80 backdrop-blur transition-all",
            isSel ? "scale-125 border-lime shadow-[0_0_20px_var(--lime)]" : "border-cyan/70 shadow-[var(--glow-cyan)]",
          )}
        >
          <Icon className={cn("h-4 w-4", isSel ? "text-lime" : meta.tone)} />
        </span>
        <span className={cn("absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border border-background", statusRing[b.status])} />
      </button>
      <div className="pointer-events-none absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded bg-background/70 px-1.5 py-0.5 font-mono text-[9px] text-cyan">
        {fmt(b.readings.energyKwh)} kWh
      </div>
      <AnimatePresence>
        {hover && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 4 }}
            transition={{ duration: 0.15 }}
            className="glass pointer-events-none absolute bottom-full left-1/2 z-30 mb-3 w-56 -translate-x-1/2 p-3 text-left"
          >
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{b.zone}</div>
            <div className="text-sm font-semibold">{b.name}</div>
            <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 font-mono text-[11px]">
              <span className="text-muted-foreground">Energy</span><span>{fmt(b.readings.energyKwh)} kWh</span>
              <span className="text-muted-foreground">Water</span><span>{fmt(b.readings.waterL)} L</span>
              <span className="text-muted-foreground">CO₂e</span><span>{fmt(b.readings.carbonKg)} kg</span>
              <span className="text-muted-foreground">AQI</span><span>{b.readings.aqi}</span>
            </div>
            <div className="mt-2 text-[10px] text-muted-foreground">Daily sample · click to select</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function CampusViewport({ tall = false }: { tall?: boolean }) {
  const { filters, toggleFilter, selectId, selected } = useDashboard();
  const [scale, setScale] = useState(1);
  const [loaded, setLoaded] = useState(false);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const frame = useRef<HTMLDivElement>(null);

  const visible = buildings.filter((b) => filters.includes(b.category));
  const byId = Object.fromEntries(buildings.map((b) => [b.id, b]));
  const zoom = (d: number) => setScale((s) => Math.min(2.5, Math.max(1, +(s + d).toFixed(2))));
  const reset = () => {
    setScale(1);
    animate(x, 0);
    animate(y, 0);
    selectId(null);
  };
  const fullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen();
    else frame.current?.requestFullscreen?.();
  };

  return (
    <div ref={frame} className="glass relative overflow-hidden p-0 [&:fullscreen]:rounded-none">
      {/* Top bar */}
      <div className="flex flex-wrap items-center gap-2 border-b px-3 py-2">
        <div className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 rounded-full bg-cyan shadow-[var(--glow-cyan)]" />
          <span className="text-xs tracking-[0.2em] text-cyan">CAMPUS DIGITAL TWIN</span>
          <span className="hidden text-[11px] text-muted-foreground sm:inline">· {selected ? selected.name : "All zones"}</span>
        </div>
        <div className="ml-auto flex flex-wrap gap-1">
          {allCategories.map((c) => {
            const M = categoryMeta[c];
            const on = filters.includes(c);
            return (
              <button
                key={c}
                onClick={() => toggleFilter(c)}
                className={cn(
                  "flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] transition-colors",
                  on ? "border-cyan/50 bg-cyan/10 text-foreground" : "text-muted-foreground opacity-60 hover:opacity-100",
                )}
                aria-pressed={on}
              >
                <M.icon className="h-3 w-3" /> {M.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Image stage */}
      <div className="relative overflow-hidden bg-background" style={tall ? undefined : { aspectRatio: `${CAMPUS_IMAGE_RATIO}` }}>
        {!loaded && <div className="absolute inset-0 animate-pulse bg-secondary/40" />}
        <motion.div
          className={cn("absolute inset-0 origin-center", scale > 1 ? "cursor-grab active:cursor-grabbing" : "")}
          style={{ x, y }}
          animate={{ scale }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          drag={scale > 1}
          dragMomentum={false}
          dragConstraints={frame}
          onClick={() => selectId(null)}
        >
          <img
            src={CAMPUS_IMAGE}
            alt="Aerial view of the university campus"
            className="absolute inset-0 h-full w-full object-cover saturate-[0.85]"
            onLoad={() => setLoaded(true)}
            draggable={false}
          />
          <div className="twin-tint absolute inset-0" />
          <div className="twin-grid absolute inset-0 opacity-50" />

          <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            {sensorLinks.map(([a, b]) => {
              const A = byId[a]!, B = byId[b]!;
              if (!filters.includes(A.category) || !filters.includes(B.category)) return null;
              const active = selected && (selected.id === a || selected.id === b);
              return (
                <line
                  key={a + b}
                  x1={A.x} y1={A.y} x2={B.x} y2={B.y}
                  className="flow-line"
                  stroke={active ? "var(--lime)" : "var(--cyan)"}
                  strokeOpacity={active ? 0.95 : 0.55}
                  strokeWidth={active ? 2 : 1.2}
                  vectorEffect="non-scaling-stroke"
                />
              );
            })}
          </svg>

          {visible.map((b) => <Marker key={b.id} b={b} scale={scale} />)}

          {[12, 30, 47, 66, 83].map((l, i) => (
            <span key={l} className="particle pointer-events-none absolute h-1 w-1 rounded-full bg-cyan" style={{ left: `${l}%`, top: `${20 + ((i * 17) % 60)}%`, animationDelay: `${i * 1.1}s` }} />
          ))}
        </motion.div>

        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="scanline absolute inset-x-0 top-0 h-[10%]" />
        </div>
        {/* corner brackets */}
        {["left-2 top-2 border-l border-t", "right-2 top-2 border-r border-t", "left-2 bottom-10 border-l border-b", "right-2 bottom-10 border-r border-b"].map((c) => (
          <span key={c} className={cn("pointer-events-none absolute h-5 w-5 border-cyan/70", c)} />
        ))}

        {/* Controls */}
        <div className="absolute right-3 top-3 z-20 flex flex-col gap-1">
          {[
            { i: Plus, f: () => zoom(0.25), l: "Zoom in" },
            { i: Minus, f: () => { zoom(-0.25); if (scale <= 1.25) { animate(x, 0); animate(y, 0); } }, l: "Zoom out" },
            { i: RotateCcw, f: reset, l: "Reset view" },
            { i: Expand, f: fullscreen, l: "Fullscreen campus" },
          ].map(({ i: I, f, l }) => (
            <button key={l} onClick={f} aria-label={l} title={l} className="grid h-8 w-8 place-items-center rounded-md border bg-background/70 text-muted-foreground backdrop-blur transition-colors hover:border-cyan/60 hover:text-cyan">
              <I className="h-4 w-4" />
            </button>
          ))}
        </div>

        {/* Legend */}
        <div className="absolute left-3 top-3 z-20 hidden rounded-md border bg-background/70 px-3 py-2 text-[10px] backdrop-blur sm:block">
          <div className="mb-1 tracking-widest text-muted-foreground">SENSOR STATUS</div>
          {(["optimal", "warning", "critical"] as const).map((s) => (
            <div key={s} className="flex items-center gap-2 capitalize">
              <span className={cn("h-2 w-2 rounded-full", statusRing[s])} /> {s}
            </div>
          ))}
        </div>

        {/* Ticker */}
        <div className="absolute inset-x-0 bottom-0 z-20 flex h-9 items-center overflow-hidden border-t bg-background/80 backdrop-blur">
          <span className="z-10 flex h-full items-center bg-cyan/15 px-3 font-mono text-[10px] tracking-widest text-cyan">LIVE · DEMO</span>
          <div className="relative flex-1 overflow-hidden">
            <div className="ticker flex w-max gap-12 whitespace-nowrap pl-6 font-mono text-[11px] text-muted-foreground">
              {[...tickerMessages, ...tickerMessages].map((m, i) => (
                <span key={i}><span className="text-cyan">▸</span> {m}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
