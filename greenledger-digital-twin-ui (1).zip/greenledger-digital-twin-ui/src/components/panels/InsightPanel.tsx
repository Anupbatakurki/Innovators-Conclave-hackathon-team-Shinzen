import { motion } from "framer-motion";
import { Link } from "@tanstack/react-router";
import { ChevronRight, Sparkles, Trophy, Flame, PiggyBank, ArrowRight, X } from "lucide-react";
import { buildings } from "@/data/campus";
import { aggregate, campusScore, fmt, rankings, recommendations } from "@/data/metrics";
import { useDashboard } from "@/lib/dashboard-context";
import { Gauge, Num } from "./MetricPanels";
import { categoryMeta } from "@/components/campus/CampusViewport";
import { cn } from "@/lib/utils";

export function SelectedBuildingCard() {
  const { selected, period, selectId, setDetailOpen } = useDashboard();
  if (!selected) {
    return (
      <div className="glass p-4 text-sm text-muted-foreground">
        <div className="text-[10px] uppercase tracking-[0.2em] text-cyan">Selection</div>
        <p className="mt-1">Entire campus · {buildings.length} monitored zones. Click a sensor marker on the map to inspect a building.</p>
      </div>
    );
  }
  const a = aggregate(selected, period);
  const M = categoryMeta[selected.category];
  return (
    <motion.div key={selected.id} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} className="glass border-lime/40 p-4">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-lime">Selected building</div>
          <div className="mt-0.5 font-semibold">{selected.name}</div>
          <div className="text-[11px] text-muted-foreground">{selected.zone} · <M.icon className="inline h-3 w-3" /> {M.label} sensor</div>
        </div>
        <button onClick={() => selectId(null)} aria-label="Clear selection" className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 font-mono text-xs">
        <div><div className="text-[9px] text-muted-foreground">ENERGY</div>{fmt(a.energyKwh)} kWh</div>
        <div><div className="text-[9px] text-muted-foreground">WATER</div>{fmt(a.waterL)} L</div>
        <div><div className="text-[9px] text-muted-foreground">CO₂e</div>{fmt(a.carbonKg)} kg</div>
      </div>
      <div className="mt-3 flex items-center justify-between">
        <span className={cn("rounded-full px-2 py-0.5 text-[10px] capitalize", selected.status === "optimal" ? "bg-teal/15 text-teal" : selected.status === "warning" ? "bg-amber/15 text-amber" : "bg-coral/15 text-coral")}>{selected.status} · score {selected.score}</span>
        <button onClick={() => setDetailOpen(true)} className="flex items-center gap-1 rounded-md bg-cyan px-3 py-1.5 text-xs font-medium text-primary-foreground transition hover:shadow-[var(--glow-cyan)]">
          Details <ArrowRight className="h-3 w-3" />
        </button>
      </div>
    </motion.div>
  );
}

export function InsightPanel() {
  const { selectId } = useDashboard();
  const { highestEnergy, bestPerformer } = rankings();
  const score = campusScore();
  const savings = recommendations.filter((r) => r.category === "energy").length * 480;
  const items = [
    { icon: Flame, tone: "text-coral", label: "Highest energy consumer", value: highestEnergy.name, sub: `${fmt(highestEnergy.readings.energyKwh)} kWh/day`, id: highestEnergy.id },
    { icon: Trophy, tone: "text-lime", label: "Best sustainable performer", value: bestPerformer.name, sub: `Score ${bestPerformer.score}/100`, id: bestPerformer.id },
    { icon: PiggyBank, tone: "text-teal", label: "Potential resource savings", value: `≈ ${fmt(savings)} kWh/day`, sub: "From open recommendations" },
  ];
  return (
    <div className="glass p-4">
      <div className="flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-cyan" />
        <h3 className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">Campus Insights</h3>
      </div>
      <div className="mt-3 flex items-center gap-3">
        <Gauge pct={score} label="score" color="var(--lime)" />
        <div>
          <div className="text-sm font-medium">Sustainability score</div>
          <div className="text-[11px] text-muted-foreground">Weighted across energy, water, waste and carbon (demo).</div>
        </div>
      </div>
      <div className="mt-3 space-y-2">
        {items.map((it) => (
          <button key={it.label} onClick={() => it.id && selectId(it.id)} className="flex w-full items-center gap-3 rounded-md border bg-background/40 p-2 text-left transition-colors hover:border-cyan/40">
            <it.icon className={cn("h-4 w-4 shrink-0", it.tone)} />
            <div className="min-w-0 flex-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{it.label}</div>
              <div className="truncate text-sm">{it.value}</div>
              <div className="font-mono text-[10px] text-muted-foreground">{it.sub}</div>
            </div>
          </button>
        ))}
      </div>
      <div className="mt-4 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Priority opportunities</div>
      <div className="mt-2 space-y-1.5">
        {recommendations.filter((r) => r.priority === "high").map((r) => (
          <button key={r.id} onClick={() => selectId(r.buildingId)} className="flex w-full items-center gap-2 rounded-md p-1.5 text-left text-xs transition-colors hover:bg-secondary/60">
            <span className="h-1.5 w-1.5 rounded-full bg-coral" />
            <span className="flex-1">{r.title}</span>
            <span className="font-mono text-[10px] text-lime">{r.impact}</span>
          </button>
        ))}
      </div>
      <Link to="/$section" params={{ section: "recommendations" }} className="mt-3 flex items-center justify-center gap-1 rounded-md border border-cyan/40 py-1.5 text-xs text-cyan transition-colors hover:bg-cyan/10">
        All recommendations <ChevronRight className="h-3 w-3" />
      </Link>
      <div className="mt-2 text-center font-mono text-[10px] text-muted-foreground">Score <Num value={score} />/100 · sample</div>
    </div>
  );
}
