import { motion } from "framer-motion";
import { useState, type ReactNode } from "react";
import { Area, AreaChart, Bar, BarChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { ChevronDown, Zap, Wind, Droplets, Factory, Recycle, TrendingDown, TrendingUp } from "lucide-react";
import { aggregate, series, fmt, periodLabel, type Period } from "@/data/metrics";
import { useDashboard } from "@/lib/dashboard-context";
import { useCountUp } from "@/hooks/use-count-up";
import { cn } from "@/lib/utils";

export function Num({ value, digits = 0, suffix = "" }: { value: number; digits?: number; suffix?: string }) {
  const v = useCountUp(value);
  return <>{digits ? v.toFixed(digits) : fmt(Math.round(v))}{suffix}</>;
}

export function PeriodSelector() {
  const { period, setPeriod } = useDashboard();
  return (
    <div className="inline-flex rounded-md border bg-background/60 p-0.5">
      {(Object.keys(periodLabel) as Period[]).map((p) => (
        <button
          key={p}
          onClick={() => setPeriod(p)}
          className={cn("relative rounded px-3 py-1 text-xs transition-colors", period === p ? "text-background" : "text-muted-foreground hover:text-foreground")}
        >
          {period === p && <motion.span layoutId="period" className="absolute inset-0 rounded bg-cyan" />}
          <span className="relative">{periodLabel[p]}</span>
        </button>
      ))}
    </div>
  );
}

export const chartTooltip = {
  contentStyle: { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 11 },
  labelStyle: { color: "var(--muted-foreground)" },
  itemStyle: { color: "var(--foreground)" },
  cursor: { stroke: "var(--cyan)", strokeOpacity: 0.3 },
};

export function Panel({ title, icon: Icon, children, detail, delay = 0, className }: {
  title: string; icon: typeof Zap; children: ReactNode; detail?: ReactNode; delay?: number | undefined; className?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.45, ease: "easeOut" }}
      className={cn("glass p-3 transition-colors hover:border-cyan/40", className)}
    >
      <header className="mb-2 flex items-center gap-2">
        <span className="grid h-7 w-7 place-items-center rounded-full border border-cyan/40 bg-cyan/10">
          <Icon className="h-3.5 w-3.5 text-cyan" />
        </span>
        <h3 className="text-[11px] font-medium uppercase tracking-[0.18em] text-muted-foreground">{title}</h3>
        {detail && (
          <button onClick={() => setOpen((o) => !o)} className="ml-auto rounded p-1 text-muted-foreground hover:text-cyan" aria-label={`Expand ${title}`} aria-expanded={open}>
            <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
          </button>
        )}
      </header>
      {children}
      {detail && (
        <motion.div initial={false} animate={{ height: open ? "auto" : 0, opacity: open ? 1 : 0 }} className="overflow-hidden">
          <div className="mt-3 border-t pt-3 text-[11px] text-muted-foreground">{detail}</div>
        </motion.div>
      )}
    </motion.section>
  );
}

export function Gauge({ pct, label, color = "var(--cyan)" }: { pct: number; label: string; color?: string }) {
  const r = 34, c = 2 * Math.PI * r;
  const v = useCountUp(pct);
  return (
    <div className="relative h-20 w-20 shrink-0">
      <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" stroke="var(--secondary)" strokeWidth="6" />
        <circle cx="40" cy="40" r={r} fill="none" stroke={color} strokeWidth="6" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - v / 100)} style={{ filter: `drop-shadow(0 0 4px ${color})` }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center leading-none">
        <div><div className="font-mono text-sm">{Math.round(v)}%</div><div className="mt-0.5 text-[8px] uppercase tracking-wider text-muted-foreground">{label}</div></div>
      </div>
    </div>
  );
}

function Delta({ pct, goodWhenDown = true }: { pct: number; goodWhenDown?: boolean }) {
  const down = pct < 0;
  const good = down === goodWhenDown;
  const I = down ? TrendingDown : TrendingUp;
  return (
    <span className={cn("inline-flex items-center gap-1 font-mono text-[11px]", good ? "text-lime" : "text-coral")}>
      <I className="h-3 w-3" /> {Math.abs(pct).toFixed(1)}% vs prev.
    </span>
  );
}

export function EnergyPanel({ delay }: { delay?: number }) {
  const { selected, period } = useDashboard();
  const a = aggregate(selected, period);
  const data = series(selected, period, "energyKwh");
  return (
    <Panel title="Energy Intelligence" icon={Zap} delay={delay} detail={<>Peak demand window 10:00–14:00. Comparison is against the previous {periodLabel[period].toLowerCase()} (sample).</>}>
      <div className="flex items-end justify-between">
        <div>
          <div className="font-mono text-2xl text-foreground"><Num value={a.energyKwh} /> <span className="text-xs text-muted-foreground">kWh</span></div>
          <Delta pct={-a.energySavedPct} />
        </div>
        <div className="text-right"><div className="font-mono text-lg text-lime"><Num value={a.energySavedPct} digits={1} suffix="%" /></div><div className="text-[10px] text-muted-foreground">saved</div></div>
      </div>
      <div className="mt-2 h-16">
        <ResponsiveContainer>
          <AreaChart data={data} margin={{ top: 4, right: 0, left: 0, bottom: 0 }}>
            <defs><linearGradient id="eg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="var(--cyan)" stopOpacity={0.5} /><stop offset="1" stopColor="var(--cyan)" stopOpacity={0} /></linearGradient></defs>
            <Tooltip {...chartTooltip} formatter={(v: number) => [`${fmt(v)} kWh`, "Energy"]} />
            <Area type="monotone" dataKey="value" stroke="var(--cyan)" strokeWidth={1.6} fill="url(#eg)" animationDuration={900} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </Panel>
  );
}

export function AirPanel({ delay }: { delay?: number }) {
  const { selected, period } = useDashboard();
  const a = aggregate(selected, period);
  const tone = (v: number, w: number, c: number) => (v >= c ? "bg-coral" : v >= w ? "bg-amber" : "bg-teal");
  const rows = [
    { l: "AQI", v: a.aqi, u: "", max: 150, t: tone(a.aqi, 50, 100) },
    { l: "CO₂", v: a.co2ppm, u: " ppm", max: 1200, t: tone(a.co2ppm, 600, 1000) },
    { l: "PM2.5", v: a.pm25, u: " µg/m³", max: 60, t: tone(a.pm25, 15, 35) },
  ];
  return (
    <Panel title="Air Quality" icon={Wind} delay={delay} detail="Thresholds: AQI 50/100, CO₂ 600/1000 ppm, PM2.5 15/35 µg/m³ (green / amber / red).">
      <div className="space-y-2.5">
        {rows.map((r) => (
          <div key={r.l}>
            <div className="flex justify-between text-[11px]"><span className="text-muted-foreground">{r.l}</span><span className="font-mono"><Num value={r.v} />{r.u}</span></div>
            <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-secondary">
              <motion.div className={cn("h-full rounded-full", r.t)} initial={{ width: 0 }} animate={{ width: `${Math.min(100, (r.v / r.max) * 100)}%` }} transition={{ duration: 0.9 }} />
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

export function WaterPanel({ delay }: { delay?: number }) {
  const { selected, period } = useDashboard();
  const a = aggregate(selected, period);
  return (
    <Panel title="Water Flow" icon={Droplets} delay={delay} detail="Recycled share includes greywater reuse and rainwater harvesting (sample estimate).">
      <div className="flex items-center gap-3">
        <Gauge pct={a.recycledWaterPct} label="reused" color="var(--teal)" />
        <div className="space-y-1">
          <div className="font-mono text-xl"><Num value={a.waterL} /> <span className="text-xs text-muted-foreground">L</span></div>
          <div className="text-[11px] text-muted-foreground">Flow ≈ <span className="font-mono text-foreground"><Num value={a.flowLpm} /> L/min</span></div>
        </div>
      </div>
    </Panel>
  );
}

export function CarbonPanel({ delay }: { delay?: number }) {
  const { selected, period } = useDashboard();
  const a = aggregate(selected, period);
  const progress = Math.min(100, (a.carbonAvoidedKg / (a.carbonKg * 0.3)) * 100);
  const data = [{ n: "Emitted", v: a.carbonKg }, { n: "Avoided", v: a.carbonAvoidedKg }];
  return (
    <Panel title="Carbon Impact" icon={Factory} delay={delay} detail="Target: avoid 30% of gross emissions through efficiency and renewables (demo target).">
      <div className="flex items-end gap-3">
        <div className="flex-1 space-y-1">
          <div className="font-mono text-xl"><Num value={a.carbonKg / 1000} digits={2} /> <span className="text-xs text-muted-foreground">t CO₂e</span></div>
          <div className="text-[11px] text-lime">−<Num value={a.carbonAvoidedKg / 1000} digits={2} /> t avoided</div>
        </div>
        <div className="h-14 w-20">
          <ResponsiveContainer>
            <BarChart data={data}><XAxis dataKey="n" hide /><Tooltip {...chartTooltip} cursor={false} formatter={(v: number) => [`${fmt(v)} kg`, ""]} /><Bar dataKey="v" radius={[3, 3, 0, 0]} fill="var(--lime)" fillOpacity={0.8} /></BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="mt-2 text-[10px] text-muted-foreground">Target progress</div>
      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-secondary">
        <motion.div className="h-full rounded-full bg-lime" initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 1 }} />
      </div>
    </Panel>
  );
}

export function WastePanel({ delay }: { delay?: number }) {
  const { selected, period } = useDashboard();
  const a = aggregate(selected, period);
  const parts = [
    { l: "Organic", v: a.waste.organic, c: "bg-lime" },
    { l: "Recyclable", v: a.waste.recyclable, c: "bg-cyan" },
    { l: "General", v: a.waste.general, c: "bg-muted-foreground" },
  ];
  return (
    <Panel title="Waste Management" icon={Recycle} delay={delay} detail="Breakdown shows average composition across selected zone(s).">
      <div className="flex items-baseline justify-between">
        <div className="font-mono text-xl"><Num value={a.wasteKg} /> <span className="text-xs text-muted-foreground">kg</span></div>
        <div className="font-mono text-sm text-teal"><Num value={a.recycledPct} suffix="%" /> <span className="text-[10px] text-muted-foreground">recycled</span></div>
      </div>
      <div className="mt-2 flex h-2 overflow-hidden rounded-full">
        {parts.map((p) => <motion.div key={p.l} className={p.c} initial={{ width: 0 }} animate={{ width: `${p.v}%` }} transition={{ duration: 0.9 }} />)}
      </div>
      <div className="mt-2 flex justify-between text-[10px] text-muted-foreground">
        {parts.map((p) => <span key={p.l} className="flex items-center gap-1"><span className={cn("h-1.5 w-1.5 rounded-full", p.c)} />{p.l} {p.v}%</span>)}
      </div>
    </Panel>
  );
}
