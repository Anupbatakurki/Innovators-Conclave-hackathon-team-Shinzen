import {
  LayoutDashboard, Map, Building2, Zap, Droplets, Trash2, Factory, Leaf,
  BarChart3, Lightbulb, FileText, Settings, type LucideIcon,
} from "lucide-react";

export interface NavItem {
  slug: string; // "" = overview
  label: string;
  icon: LucideIcon;
}

export const navItems: NavItem[] = [
  { slug: "", label: "Overview", icon: LayoutDashboard },
  { slug: "campus-map", label: "Campus Map", icon: Map },
  { slug: "buildings", label: "Buildings", icon: Building2 },
  { slug: "energy", label: "Energy", icon: Zap },
  { slug: "water", label: "Water", icon: Droplets },
  { slug: "waste", label: "Waste Management", icon: Trash2 },
  { slug: "carbon", label: "Carbon Footprint", icon: Factory },
  { slug: "sustainability", label: "Sustainability", icon: Leaf },
  { slug: "analytics", label: "Analytics", icon: BarChart3 },
  { slug: "recommendations", label: "Recommendations", icon: Lightbulb },
  { slug: "reports", label: "Reports", icon: FileText },
  { slug: "settings", label: "Settings", icon: Settings },
];

export const sectionSlugs = navItems.filter((n) => n.slug).map((n) => n.slug);
