import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { buildings, type Building, type SensorCategory } from "@/data/campus";
import type { Period } from "@/data/metrics";

export const allCategories: SensorCategory[] = ["energy", "water", "waste", "air", "carbon", "renewable"];

interface DashboardState {
  selected: Building | null;
  selectId: (id: string | null) => void;
  period: Period;
  setPeriod: (p: Period) => void;
  filters: SensorCategory[];
  toggleFilter: (c: SensorCategory) => void;
  alertsOpen: boolean;
  setAlertsOpen: (v: boolean) => void;
  detailOpen: boolean;
  setDetailOpen: (v: boolean) => void;
  mobileNavOpen: boolean;
  setMobileNavOpen: (v: boolean) => void;
}

const Ctx = createContext<DashboardState | null>(null);

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [period, setPeriod] = useState<Period>("today");
  const [filters, setFilters] = useState<SensorCategory[]>(allCategories);
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const value = useMemo<DashboardState>(
    () => ({
      selected: buildings.find((b) => b.id === selectedId) ?? null,
      selectId: setSelectedId,
      period,
      setPeriod,
      filters,
      toggleFilter: (c) =>
        setFilters((f) => (f.includes(c) ? f.filter((x) => x !== c) : [...f, c])),
      alertsOpen,
      setAlertsOpen,
      detailOpen,
      setDetailOpen,
      mobileNavOpen,
      setMobileNavOpen,
    }),
    [selectedId, period, filters, alertsOpen, detailOpen, mobileNavOpen],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useDashboard() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useDashboard must be used inside DashboardProvider");
  return v;
}
