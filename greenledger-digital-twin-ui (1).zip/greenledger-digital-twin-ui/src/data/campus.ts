/**
 * Campus configuration — edit building names, marker positions (x/y in % of
 * the campus image) and demo readings here. All values are DEMO / SAMPLE data.
 * Replace with API responses via src/data/metrics.ts when a backend exists.
 */
export type SensorCategory = "energy" | "water" | "waste" | "air" | "carbon" | "renewable";
export type Status = "optimal" | "warning" | "critical";

export interface DailyReadings {
  energyKwh: number;
  energySavedPct: number;
  waterL: number;
  flowLpm: number;
  recycledWaterPct: number;
  aqi: number;
  co2ppm: number;
  pm25: number;
  carbonKg: number;
  carbonAvoidedKg: number;
  wasteKg: number;
  recycledPct: number;
  waste: { organic: number; recyclable: number; general: number };
}

export interface Building {
  id: string;
  name: string;
  zone: string;
  category: SensorCategory;
  x: number;
  y: number;
  status: Status;
  score: number;
  readings: DailyReadings;
}

export const CAMPUS_IMAGE = "/images/university-campus.png";
export const CAMPUS_IMAGE_RATIO = 1471 / 1069;
export const CAMPUS_NAME = "University Campus";

export const buildings: Building[] = [
  {
    id: "admin",
    name: "Administration (Dome)",
    zone: "Central Quad — North",
    category: "energy",
    x: 61,
    y: 28,
    status: "warning",
    score: 68,
    readings: { energyKwh: 4820, energySavedPct: 8.2, waterL: 18400, flowLpm: 42, recycledWaterPct: 22, aqi: 46, co2ppm: 612, pm25: 14, carbonKg: 3420, carbonAvoidedKg: 410, wasteKg: 210, recycledPct: 48, waste: { organic: 30, recyclable: 45, general: 25 } },
  },
  {
    id: "academic-a",
    name: "Academic Block A",
    zone: "Central Quad — West",
    category: "air",
    x: 33,
    y: 37,
    status: "optimal",
    score: 84,
    readings: { energyKwh: 3610, energySavedPct: 14.6, waterL: 12600, flowLpm: 31, recycledWaterPct: 35, aqi: 32, co2ppm: 498, pm25: 9, carbonKg: 2560, carbonAvoidedKg: 620, wasteKg: 160, recycledPct: 62, waste: { organic: 28, recyclable: 52, general: 20 } },
  },
  {
    id: "library",
    name: "Central Library",
    zone: "Central Quad — South",
    category: "carbon",
    x: 49,
    y: 57,
    status: "optimal",
    score: 88,
    readings: { energyKwh: 2980, energySavedPct: 18.1, waterL: 8400, flowLpm: 19, recycledWaterPct: 41, aqi: 28, co2ppm: 455, pm25: 7, carbonKg: 2110, carbonAvoidedKg: 740, wasteKg: 95, recycledPct: 71, waste: { organic: 18, recyclable: 64, general: 18 } },
  },
  {
    id: "engineering",
    name: "Engineering Block",
    zone: "Central Quad — East",
    category: "energy",
    x: 70,
    y: 50,
    status: "critical",
    score: 54,
    readings: { energyKwh: 6240, energySavedPct: 3.4, waterL: 15200, flowLpm: 37, recycledWaterPct: 18, aqi: 61, co2ppm: 784, pm25: 22, carbonKg: 4430, carbonAvoidedKg: 190, wasteKg: 260, recycledPct: 39, waste: { organic: 22, recyclable: 40, general: 38 } },
  },
  {
    id: "convention",
    name: "Convention Hall",
    zone: "North Lawn",
    category: "water",
    x: 54,
    y: 10,
    status: "optimal",
    score: 79,
    readings: { energyKwh: 2140, energySavedPct: 11.9, waterL: 9800, flowLpm: 24, recycledWaterPct: 46, aqi: 35, co2ppm: 520, pm25: 10, carbonKg: 1520, carbonAvoidedKg: 380, wasteKg: 120, recycledPct: 58, waste: { organic: 35, recyclable: 43, general: 22 } },
  },
  {
    id: "sports",
    name: "Sports Complex",
    zone: "North-West Fields",
    category: "water",
    x: 25,
    y: 8,
    status: "warning",
    score: 66,
    readings: { energyKwh: 1880, energySavedPct: 6.7, waterL: 26800, flowLpm: 64, recycledWaterPct: 28, aqi: 38, co2ppm: 430, pm25: 12, carbonKg: 1330, carbonAvoidedKg: 160, wasteKg: 140, recycledPct: 44, waste: { organic: 40, recyclable: 32, general: 28 } },
  },
  {
    id: "hostels",
    name: "Residential Hostels",
    zone: "West Residences",
    category: "waste",
    x: 14,
    y: 27,
    status: "warning",
    score: 63,
    readings: { energyKwh: 3920, energySavedPct: 7.5, waterL: 31200, flowLpm: 71, recycledWaterPct: 24, aqi: 41, co2ppm: 560, pm25: 15, carbonKg: 2790, carbonAvoidedKg: 300, wasteKg: 480, recycledPct: 41, waste: { organic: 52, recyclable: 28, general: 20 } },
  },
  {
    id: "solar-park",
    name: "Solar Car Park",
    zone: "South-East Parking",
    category: "renewable",
    x: 74,
    y: 83,
    status: "optimal",
    score: 95,
    readings: { energyKwh: 420, energySavedPct: 41.0, waterL: 900, flowLpm: 3, recycledWaterPct: 60, aqi: 44, co2ppm: 410, pm25: 13, carbonKg: 300, carbonAvoidedKg: 1650, wasteKg: 30, recycledPct: 80, waste: { organic: 10, recyclable: 70, general: 20 } },
  },
];

/** Pairs of building ids connected by animated data-link lines. */
export const sensorLinks: [string, string][] = [
  ["admin", "academic-a"],
  ["admin", "engineering"],
  ["academic-a", "library"],
  ["library", "engineering"],
  ["admin", "convention"],
  ["academic-a", "hostels"],
  ["hostels", "sports"],
  ["engineering", "solar-park"],
];
