/**
 * Data integration layer. Every function here returns DEMO data derived from
 * src/data/campus.ts. Swap the bodies for API calls later; keep the shapes.
 */
import { buildings, type Building, type DailyReadings, type SensorCategory } from "./campus";

export type Period = "today" | "7d" | "30d";
export const periodDays: Record<Period, number> = { today: 1, "7d": 7, "30d": 30 };
export const periodLabel: Record<Period, string> = { today: "Today", "7d": "7 Days", "30d": "30 Days" };

export interface Aggregate extends DailyReadings {
  label: string;
}

const avg = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0);

export function aggregate(selected: Building | null, period: Period): Aggregate {
  const d = periodDays[period];
  const list = selected ? [selected] : buildings;
  const r = list.map((b) => b.readings);
  const wasteKg = sum(r.map((x) => x.wasteKg)) * d;
  return {
    label: selected ? selected.name : "Entire campus",
    energyKwh: sum(r.map((x) => x.energyKwh)) * d,
    energySavedPct: avg(r.map((x) => x.energySavedPct)),
    waterL: sum(r.map((x) => x.waterL)) * d,
    flowLpm: sum(r.map((x) => x.flowLpm)),
    recycledWaterPct: avg(r.map((x) => x.recycledWaterPct)),
    aqi: Math.round(avg(r.map((x) => x.aqi))),
    co2ppm: Math.round(avg(r.map((x) => x.co2ppm))),
    pm25: Math.round(avg(r.map((x) => x.pm25))),
    carbonKg: sum(r.map((x) => x.carbonKg)) * d,
    carbonAvoidedKg: sum(r.map((x) => x.carbonAvoidedKg)) * d,
    wasteKg,
    recycledPct: avg(r.map((x) => x.recycledPct)),
    waste: {
      organic: Math.round(avg(r.map((x) => x.waste.organic))),
      recyclable: Math.round(avg(r.map((x) => x.waste.recyclable))),
      general: Math.round(avg(r.map((x) => x.waste.general))),
    },
  };
}

/** Deterministic pseudo-random so charts are stable across renders. */
function seeded(seed: number) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

export function series(selected: Building | null, period: Period, key: "energyKwh" | "waterL" | "carbonKg" | "wasteKg" = "energyKwh") {
  const points = period === "today" ? 12 : period === "7d" ? 7 : 30;
  const base = aggregate(selected, "today")[key] / (period === "today" ? 12 : 1);
  const rnd = seeded((selected?.id.length ?? 3) * 31 + points + key.length);
  return Array.from({ length: points }, (_, i) => {
    const wave = period === "today" ? Math.sin((i / 11) * Math.PI) * 0.45 + 0.75 : 0.85 + rnd() * 0.3;
    const value = Math.round(base * wave * (0.92 + rnd() * 0.16));
    const prev = Math.round(value * (1.04 + rnd() * 0.1));
    const label = period === "today" ? `${String(i * 2).padStart(2, "0")}:00` : period === "7d" ? ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][i] : `D${i + 1}`;
    return { label, value, prev };
  });
}

export function campusScore() {
  return Math.round(avg(buildings.map((b) => b.score)));
}

export function rankings() {
  const byEnergy = [...buildings].sort((a, b) => b.readings.energyKwh - a.readings.energyKwh);
  const byScore = [...buildings].sort((a, b) => b.score - a.score);
  return { highestEnergy: byEnergy[0]!, bestPerformer: byScore[0]! };
}

export interface Recommendation {
  id: string;
  buildingId: string;
  title: string;
  detail: string;
  impact: string;
  priority: "high" | "medium" | "low";
  category: SensorCategory;
}

export const recommendations: Recommendation[] = [
  { id: "r1", buildingId: "engineering", title: "Schedule HVAC setback after 19:00", detail: "Lab HVAC runs at full load overnight. A setback schedule could trim baseline demand.", impact: "≈ 620 kWh/day", priority: "high", category: "energy" },
  { id: "r2", buildingId: "hostels", title: "Install low-flow fixtures in hostels", detail: "Residential water use is the highest on campus per occupant.", impact: "≈ 5,800 L/day", priority: "high", category: "water" },
  { id: "r3", buildingId: "admin", title: "Upgrade dome lighting to LED + sensors", detail: "Façade and corridor lighting remain on during daylight hours.", impact: "≈ 340 kWh/day", priority: "medium", category: "energy" },
  { id: "r4", buildingId: "hostels", title: "Add organic waste composting point", detail: "Over half of hostel waste is organic and could be composted on site.", impact: "≈ 210 kg/day diverted", priority: "medium", category: "waste" },
  { id: "r5", buildingId: "sports", title: "Reuse greywater for field irrigation", detail: "Irrigation currently uses potable supply.", impact: "≈ 7,500 L/day", priority: "medium", category: "water" },
  { id: "r6", buildingId: "solar-park", title: "Extend solar canopy to east row", detail: "Car park canopy performs best on campus; expansion has space.", impact: "≈ 0.6 t CO₂e/day avoided", priority: "low", category: "renewable" },
];

export interface Alert {
  id: string;
  level: "critical" | "warning" | "info";
  title: string;
  time: string;
  buildingId?: string;
}

export const alerts: Alert[] = [
  { id: "a1", level: "critical", title: "Engineering Block energy 38% above baseline", time: "4 min ago", buildingId: "engineering" },
  { id: "a2", level: "warning", title: "Hostel water flow elevated overnight", time: "22 min ago", buildingId: "hostels" },
  { id: "a3", level: "warning", title: "Administration CO₂ above 600 ppm", time: "41 min ago", buildingId: "admin" },
  { id: "a4", level: "info", title: "Solar Car Park reached daily generation target", time: "1 h ago", buildingId: "solar-park" },
];

export const tickerMessages = [
  "ENERGY · Monitoring active across 8 zones",
  "WATER · Resource optimisation available for Residential Hostels",
  "SUSTAINABILITY · Target progress updated",
  "ALERT · Review high-consumption building: Engineering Block",
  "RENEWABLE · Solar Car Park generation on target",
  "SYSTEM · All demo services operational",
];

export function fmt(n: number, digits = 0) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(2)}M`;
  if (n >= 10_000) return `${(n / 1000).toFixed(1)}k`;
  return n.toLocaleString("en-US", { maximumFractionDigits: digits });
}
