<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- All dashboard readings come from `src/data/campus.ts` (config) and `src/data/metrics.ts` (data layer); swap metrics.ts bodies for API calls later — keeps UI decoupled from data source.
- Shared dashboard state (selected building, period, filters, drawers) lives in `src/lib/dashboard-context.tsx`, provided in `__root.tsx` — so map, panels and section pages stay in sync.
- Non-overview nav sections render through the single `/$section` route + `SectionView` — one place to add views, no dead links.
- Campus marker positions are percentages of the aerial image inside a fixed-aspect stage — overlays stay aligned at any size.
